insert into SWORK (SID, EmpID) values (201, 4);
insert into SWORK (SID, EmpID) values (200, 5);
insert into SWORK (SID, EmpID) values (201, 9);
