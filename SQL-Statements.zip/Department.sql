insert into Department (DepID, Dname) values (1, 'Marketing');
insert into Department (DepID, Dname) values (2, 'Mountain Misery');
