insert into Product (ProdID, Price, Type1, Style, Weight) values (67, 5445, 'Public Utilities', 'video/x-msvideo', 957, 100);
insert into Product (ProdID, Price, Type1, Style, Weight) values (72, 9043, 'Basic Industries', 'application/mspowerpoint', 200);
insert into Product (ProdID, Price, Type1, Style, Weight) values (100, 1454, 'Finance', 'image/jpeg', 312);
insert into Product (ProdID, Price, Type1, Style, Weight) values (93, 1436, 'Consumer Non-Durables', 'application/mspowerpoint', 300);
insert into Product (ProdID, Price, Type1, Style, Weight) values (85, 7501, 'Capital Goods', 'application/vnd.ms-powerpoint', 150);
